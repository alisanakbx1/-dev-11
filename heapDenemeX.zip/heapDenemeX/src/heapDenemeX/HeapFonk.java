package heapDenemeX;

public class HeapFonk {
	int[] dizi2;
	int es;
	
	
	public HeapFonk(int boyut) {
			dizi2 = new int[boyut];
			es = 0;
				
	}
	
	
	public void add(int a) {   //heap algoritmasi
		if (es==0) {
			dizi2[es++]=a;
		
		}else {
			int m=0;	
			int kontrol = 0;
			dizi2[es]=a;
			if((es%3)==2) {  
				m=2;
				kontrol = (es-2)/3; // parente ulasma
			}else if((es%3)==1) {
				m = 1;
				kontrol =(es-1)/3;
			}else {
				m = 0;
				kontrol = (es-3)/3;	
			}
			while(dizi2[es]<dizi2[kontrol]) {
					int tmp = dizi2[kontrol];
					dizi2[kontrol]=dizi2[es];
					dizi2[es]=tmp;
					if (kontrol==0) { //roota ulastiysa donguden ciksin
						break;
					}else {
						if (m==2) {
							kontrol = (kontrol-2)/3;
						}else if(m==1) {
							kontrol = (kontrol-1)/3;
						}else {
							kontrol = (kontrol-3)/3;
						}
					}
					
			}
			es++;
		}
	}
	
	public int[] goruntule2() {
		return dizi2;
	}
}
