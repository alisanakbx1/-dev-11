package heapDenemeX;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("kac eleman gireceksiniz"); //virgul kullanarak yapamadim
		int eleman_say = input.nextInt();   //sirayla eleman aldirip aldirdigim elemanlari
		HeapFonk e1 = new HeapFonk(eleman_say); //hem yeni ekledigim diziye attim
		int es1 = 0;        // hemde o elemani fonksiyonuma gonderip dizi2 ye ekledi
		int[] dizi1 = new int[eleman_say]; //dizi2 yi fonksiyonumuz heape uygun sekilde duzeltti
		for(int i=0;i<eleman_say;i++) {  //yorum satirlarini ard arda yazdim
			System.out.println("eleman girin");
			int deger = input.nextInt();
			dizi1[es1++]=deger;  
			e1.add(deger);
		}
		
		
		//char virgul = ',';
		/*for(int i=0;i<metin.length();i++) {  //virgulle yapmaya calistim string ifade icinde 
			if(metin.charAt(i)!=virgul) {	//ama string ifadenin indeksinin verisine
				int b = i;			//ulasamadigim icin yapamadim
				dizi1[es1++]=b;
				e1.add(b);
			}
		}
		*/
		System.out.println("dizi1:");
		for(int j=0;j<es1;j++) {
			System.out.print(dizi1[j]+"  ");
		}
		e1.goruntule2();
		int[] kontr = e1.goruntule2(); 
		if(dizi1==kontr) {
			System.out.println("olusan dizi heap ile ayni");
		}else {
			System.out.println();
			System.out.println("olusan dizi heap degil");
			System.out.println("dizinin heapi:");
			for(int m=0;m<eleman_say;m++) {
				System.out.print(kontr[m]+"  ");
			}
		}
		
	}
	

}
