
public class Harfler {
	
	public static void insertion_sort(int[] dizi1,char[] dizi2) {  //siralamak icin insertion sort kullandim
		int es = dizi1.length;
		for(int i=0;i<es-1;i++) {
			int a=i;
			for(int j=i+1;j<es;j++) {     
				if(dizi1[a]>dizi1[j]) {	
					a=j;						
				}
			}
			int b=dizi1[i];
			dizi1[i]=dizi1[a];
			dizi1[a]=b;
			char c = dizi2[i];
			dizi2[i]=dizi2[a];
			dizi2[a]=c;
		}
	}
	
	public void yazdir1(int[] dizi1) {
		for(int i=0;i<dizi1.length;i++)      //ayri ayri print etme tanimladik
			System.out.println(dizi1[i]+"  ");
	}
	
	public void yazdir2(char[] dizi2) {
		for(int i=0;i<dizi2.length;i++) {
			System.out.println(dizi2[i]+"  ");
		}
	}
	
	public int sayac_a(String metin) {  //belirledigimiz harflerin tekrar sayilarini bulmak icin  metotlar olusturduk
		
		char karakter1 = 'a';
		int count_a = 0; 
		
		for(int i=0;i<metin.length();i++) {
			if(metin.charAt(i)==karakter1) {  //metnimizin icinde belirledigimiz harf varmi diye indeks indeks kontrol ediyor
				count_a++; //varsa countu bir artır
			}
		}
		return count_a;   //fonk cagirildiginda tekrar sayisini dondur
		
	}
	
	public int sayac_e(String metin) {
		
		char karakter2 = 'e';
		int count_e = 0; 
		
		for(int i=0;i<metin.length();i++) {
			if(metin.charAt(i)==karakter2) {
				count_e++;
			}
		}
		return count_e;
		
	}
	
	public int sayac_k(String metin) {
		
		char karakter3 = 'k';
		int count_k = 0; 
		
		for(int i=0;i<metin.length();i++) {
			if(metin.charAt(i)==karakter3) {
				count_k++;
			}
		}
		return count_k;
		
	}
	
	public int sayac_d(String metin) {
		
		char karakter4 = 'd';
		int count_d = 0; 
		
		for(int i=0;i<metin.length();i++) {
			if(metin.charAt(i)==karakter4) {
				count_d++;
			}
		}
		return count_d;
		
	}
	
	public int sayac_m(String metin) {
		
		char karakter5 = 'm';
		int count_m = 0; 
		
		for(int i=0;i<metin.length();i++) {
			if(metin.charAt(i)==karakter5) {
				count_m++;
			}
		}
		return count_m;
		
	}
	
}
