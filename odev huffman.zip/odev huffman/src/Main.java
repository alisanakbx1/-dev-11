import java.util.Scanner;

public class Main {
	
	static Harfler tekrarlari = new Harfler(); 

	
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		String metin1; //
		
		System.out.println("metin giriniz (uygulamamiz sadece a-e-d-k-m harflerini kabul eder ");
		metin1 = input.nextLine(); // girilecek metni istiyoruz
		
		char[] alfabe = new char[5]; // karakterlerden olusan alfabemizi koymak icin liste tanimladik
		
		alfabe[0]='a'; alfabe[1]='e';   // degerleri atiyoruz
		alfabe[2]='d'; alfabe[3]='k'; alfabe[4]='m';
		
		int[] sayaclar = new int[5];  // harflerimiz ile ayni indekste olucak sekilde sayac listemizi tanimladik
		// ve sirasiyla metotlarimiz yardimiyla tekrar sayilarini yerlestiriyoruz
		sayaclar[0]=tekrarlari.sayac_a(metin1);
		sayaclar[1]=tekrarlari.sayac_e(metin1);
		sayaclar[2]=tekrarlari.sayac_d(metin1);
		sayaclar[3]=tekrarlari.sayac_k(metin1);
		sayaclar[4]=tekrarlari.sayac_m(metin1);
		
		tekrarlari.insertion_sort(sayaclar, alfabe);  //sayaclar ve alfabemiz listeleri istedigimiz sekilde siralandi
		
		System.out.println("sayaclar:");
		tekrarlari.yazdir1(sayaclar);
		System.out.println("harfler:");
		tekrarlari.yazdir2(alfabe);
		
		//hocam bundan sonrasini  yaptim ama emin degilim iyi bir not temennisi ile :))
		
		//siraladigmiz icin sonucun bu tarz bir cikti uretmesi lazim
		
		System.out.println();
		
		int[] dizi3 = {00,01,10,11,100}; //son deger iki bit oluyor yani 1 00 biz iki biti aliriz
		System.out.println("sonuc:");
		tekrarlari.yazdir1(dizi3);
		
		
		
		
		
		
	}

}
